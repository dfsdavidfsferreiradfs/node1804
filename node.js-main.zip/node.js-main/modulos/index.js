const calculator = require("./calculator");

console.log("2+3= ",calculator.mais(2, 3));
console.log("7-5= ",calculator.menos(7, 5));
console.log("4*6= ",calculator.vezes(4, 6));
console.log("9/3= ",calculator.dividido(9, 3)),
console.log("8/0= ",calculator.dividido(8, 0));